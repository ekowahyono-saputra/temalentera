@extends('admin.layouts.index')
@section('title')<h1>Notifikasi WhatsApp <small>Layanan Surat</small></h1>@endsection
@section('content')
<div class="box box-success"><div class="box-header with-border"><h3 class="box-title">Periksa penerima dan pesan</h3></div><div class="box-body">
@if ($result)<div class="alert {{ $result['ok'] ? 'alert-success' : 'alert-warning' }}">{{ $result['message'] }}</div>@endif
<dl><dt>Jenis surat</dt><dd>{{ $title }}</dd><dt>Pemohon</dt><dd>{{ $name }}</dd><dt>Status data</dt><dd>{{ $status }}</dd></dl>
@if (!$phone)<div class="alert alert-warning">Nomor pemohon belum tersedia atau tidak valid. Verifikasi langsung sebelum mengisi nomor tujuan.</div>@endif
{!! form_open($form_action) !!}
<input type="hidden" name="notice_token" value="{{ $token }}">
<div class="form-group"><label for="le-notice-number">Nomor WhatsApp penerima</label><input class="form-control" id="le-notice-number" name="number" type="tel" required maxlength="20" value="{{ $phone }}"><p class="help-block">Permohonan: nomor aktif pemohon. Arsip: nomor data penduduk pemohon. Pastikan bukan nomor terlapor yang berbeda dari pemohon.</p></div>
<div class="form-group"><label for="le-notice-message">Pesan notifikasi</label><textarea class="form-control" id="le-notice-message" name="message" rows="4" required maxlength="2000">{{ $message }}</textarea><p class="help-block">Pesan teks melalui Mpedia. Tidak melampirkan berkas surat atau membuka tautan dokumen publik.</p></div>
<div class="checkbox"><label><input type="checkbox" name="verified" value="1" required> Saya telah memeriksa nomor penerima dan isi notifikasi.</label></div>
<a class="btn btn-default" href="{{ $back }}">Kembali</a> <button class="btn btn-success" type="submit"><i class="fa fa-whatsapp"></i> Kirim notifikasi</button>
</form></div></div>
@endsection
