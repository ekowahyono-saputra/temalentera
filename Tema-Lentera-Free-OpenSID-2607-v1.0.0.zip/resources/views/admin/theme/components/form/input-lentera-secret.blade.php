<input type="password" class="form-control input-sm" id="input{{ $value['key'] }}" name="opsi[{{ $value['key'] }}]" value="{{ $value['default'] }}" autocomplete="new-password" spellcheck="false">
