# Lentera Free 1.0.0

Edisi Free terpisah dari Lentera 1.26, untuk OpenSID publik 2607.0.1.

- Beranda dapat tampil tanpa aktivasi.
- Kotak aktivasi, API key lisensi, nomor instalasi, endpoint dan service aktivasi dihapus.
- Pengaturan dan tautan OpenSID Updater dihapus.
- Tampilan admin, login kustom, widget cuaca/gempa dan gateway WhatsApp mengikuti pengaturan masing-masing.
- Nama folder tetap desa/themes/lentera agar struktur dan referensi internal konsisten.
- Pengembangan dukungan OpenSID Premium masih ditunda.

Paket tidak mempunyai tanggal kedaluwarsa atau aktivasi tersembunyi.
