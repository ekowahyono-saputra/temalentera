/* Lentera 1.23: public WhatsApp uses a direct wa.me link. No public message submission. */
