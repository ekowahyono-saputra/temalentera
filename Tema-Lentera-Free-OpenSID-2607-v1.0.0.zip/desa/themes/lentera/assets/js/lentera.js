/* Nested dropdowns remain operable with touch and keyboard. */
document.addEventListener('DOMContentLoaded',function(){
 var nav=document.getElementById('le-navigation');
 if(!nav)return;
 nav.querySelectorAll('.dropdown').forEach(function(item){
  var a=item.querySelector(':scope > a');
  if(!a)return;
  a.setAttribute('aria-haspopup','true');a.setAttribute('aria-expanded','false');
  a.addEventListener('click',function(e){
   if(window.matchMedia('(max-width:767px)').matches&&!item.classList.contains('le-open')){
    e.preventDefault();e.stopPropagation();item.classList.add('le-open','open');a.setAttribute('aria-expanded','true');
   }
  });
  a.addEventListener('keydown',function(e){
   if(e.key==='Escape'){item.classList.remove('le-open','open');a.setAttribute('aria-expanded','false');a.blur();}
   if(e.key===' '){e.preventDefault();item.classList.toggle('open');a.setAttribute('aria-expanded',String(item.classList.contains('open')));}
  });
 });
});

document.addEventListener('DOMContentLoaded',function(){
 document.querySelectorAll('.le-carousel').forEach(function(carousel){
  var track=carousel.querySelector('.le-slides'),slides=Array.from(track.querySelectorAll('.le-slide')),counter=carousel.querySelector('.le-slide-count'),play=carousel.querySelector('[data-slide-play]'),current=0,timer=null,startX=null;
  var reduced=matchMedia('(prefers-reduced-motion:reduce)');
  if(!slides.length)return;
  carousel.classList.add('le-carousel-fade');
  function show(next){
   current=(next+slides.length)%slides.length;
   slides.forEach(function(slide,i){var active=i===current;slide.classList.toggle('is-active',active);slide.setAttribute('aria-hidden',String(!active));slide.tabIndex=active?0:-1;slide.inert=!active;});
   if(counter)counter.textContent=(current+1)+' / '+slides.length;
  }
  function stop(){clearInterval(timer);timer=null;if(play){play.setAttribute('aria-pressed','false');play.setAttribute('aria-label','Putar slider otomatis');play.innerHTML='<i class="fa fa-play" aria-hidden="true"></i>';}}
  function start(){stop();if(slides.length<2)return;timer=setInterval(function(){if(!document.hidden&&!carousel.matches(':hover')&&!carousel.contains(document.activeElement))show(current+1);},6000);if(play){play.setAttribute('aria-pressed','true');play.setAttribute('aria-label','Jeda slider');play.innerHTML='<i class="fa fa-pause" aria-hidden="true"></i>';}}
  carousel.querySelectorAll('[data-slide]').forEach(function(button){button.addEventListener('click',function(){stop();show(current+Number(button.dataset.slide));});});
  track.addEventListener('keydown',function(e){if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();stop();show(current+(e.key==='ArrowRight'?1:-1));}});
  track.addEventListener('touchstart',function(e){startX=e.touches[0].clientX;},{passive:true});
  track.addEventListener('touchend',function(e){if(startX!==null){var delta=e.changedTouches[0].clientX-startX;if(Math.abs(delta)>45){stop();show(current+(delta<0?1:-1));}startX=null;}},{passive:true});
  if(play)play.addEventListener('click',function(){if(timer)stop();else start();});
  show(0);if(!reduced.matches)start();
  reduced.addEventListener('change',function(){if(reduced.matches)stop();});
 });
 document.querySelectorAll('.le-mobile-nav a').forEach(function(a){if(a.pathname.replace(/\/$/,'')===location.pathname.replace(/\/$/,'') && a.search===location.search)a.setAttribute('aria-current','page');});
 var button=document.querySelector('[data-mobile-menu]'),nav=document.getElementById('le-navigation');
 if(button&&nav)button.addEventListener('click',function(){
  var open=!nav.classList.contains('in');
  if(window.jQuery&&window.jQuery.fn.collapse){window.jQuery(nav).collapse(open?'show':'hide');}else{nav.classList.toggle('in',open);}
  button.setAttribute('aria-expanded',String(open));
  var toggle=document.querySelector('[data-target="#le-navigation"]');if(toggle)toggle.setAttribute('aria-expanded',String(open));
  if(open){nav.closest('nav').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth',block:'start'});}
 });
});

document.addEventListener('DOMContentLoaded',function(){
 var toggle=document.querySelector('[data-target="#le-navigation"]'),nav=document.getElementById('le-navigation');
 if(toggle&&nav&&!(window.jQuery&&window.jQuery.fn.collapse)){toggle.addEventListener('click',function(){nav.classList.toggle('in');toggle.setAttribute('aria-expanded',String(nav.classList.contains('in')));});}
});


document.addEventListener('DOMContentLoaded',function(){
 document.querySelectorAll('.le-nav .dropdown-menu .dropdown').forEach(function(item){
  function align(){if(innerWidth<768)return;var menu=item.querySelector(':scope > .dropdown-menu');if(!menu)return;item.classList.remove('le-submenu-left');if(menu.getBoundingClientRect().right>innerWidth-12)item.classList.add('le-submenu-left');}
  item.addEventListener('mouseenter',align);item.addEventListener('focusin',align);
 });
});

document.addEventListener('DOMContentLoaded',function(){
 var bar=document.querySelector('.le-brandbar'),button=document.querySelector('.le-search-toggle'),input=document.getElementById('le-search-input');
 if(bar&&button&&input){
  bar.classList.add('search-ready');
  function openSearch(open){bar.classList.toggle('search-open',open);button.setAttribute('aria-expanded',String(open));button.setAttribute('aria-label',open?'Tutup pencarian':'Buka pencarian');if(open)input.focus();}
  if(input.value)openSearch(true);
  button.addEventListener('click',function(){openSearch(!bar.classList.contains('search-open'));});
  input.addEventListener('keydown',function(e){if(e.key==='Escape'){openSearch(false);button.focus();}});
 }
 var tabs=Array.from(document.querySelectorAll('[data-news-tab]'));
 function selectTab(tab){tabs.forEach(function(t){var active=t===tab;t.setAttribute('aria-selected',String(active));t.tabIndex=active?0:-1;var panel=document.getElementById(t.getAttribute('aria-controls'));if(panel)panel.hidden=!active;});}
 tabs.forEach(function(tab,i){tab.addEventListener('click',function(){selectTab(tab);});tab.addEventListener('keydown',function(e){if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();var next=tabs[(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length];selectTab(next);next.focus();}});});
 if(tabs.length)selectTab(tabs[0]);
});

document.addEventListener('DOMContentLoaded',function(){
 document.querySelectorAll('.le-live-clock').forEach(function(clock){
  var zone=clock.dataset.timezone||'Asia/Jakarta',dateFormat,timeFormat;
  function formatters(){dateFormat=new Intl.DateTimeFormat('id-ID',{timeZone:zone,weekday:'long',day:'numeric',month:'long',year:'numeric'});timeFormat=new Intl.DateTimeFormat('id-ID',{timeZone:zone,hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});}
  try{formatters();}catch(e){zone='Asia/Jakarta';formatters();}
  var labels={'Asia/Jakarta':'WIB','Asia/Pontianak':'WIB','Asia/Makassar':'WITA','Asia/Jayapura':'WIT'};
  function tick(){var now=new Date();clock.querySelector('time').dateTime=now.toISOString();clock.querySelector('.le-clock-date').textContent=dateFormat.format(now);clock.querySelector('.le-clock-time').textContent=timeFormat.format(now).replace(/\./g,':');clock.querySelector('.le-clock-zone').textContent=labels[zone]||zone;}
  tick();setInterval(function(){if(!document.hidden)tick();},1000);document.addEventListener('visibilitychange',function(){if(!document.hidden)tick();});
 });
});

/* Local interactions only: no AJAX, polling or additional libraries. */
document.addEventListener('DOMContentLoaded',function(){
 document.querySelectorAll('.le-insight').forEach(function(section){
  var tabs=Array.from(section.querySelectorAll('[data-insight-tab]')),panels=section.querySelectorAll('.le-insight-panel');
  section.querySelector('.le-insight-tabs').setAttribute('role','tablist');
  function select(index){tabs.forEach(function(tab,i){tab.setAttribute('role','tab');tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;});panels.forEach(function(panel){panel.setAttribute('role','tabpanel');panel.hidden=panel.id!=='le-insight-'+tabs[index].dataset.insightTab;});}
  tabs.forEach(function(tab,i){tab.addEventListener('click',function(){select(i);});tab.addEventListener('keydown',function(e){var n=i;if(e.key==='ArrowRight')n=(i+1)%tabs.length;else if(e.key==='ArrowLeft')n=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')n=0;else if(e.key==='End')n=tabs.length-1;else return;e.preventDefault();select(n);tabs[n].focus();});});select(0);
  var expand=section.querySelector('[data-insight-expand]');
  function expanded(on){section.classList.toggle('is-expanded',on);expand.setAttribute('aria-expanded',String(on));expand.setAttribute('aria-label',on?'Kecilkan Smart Insight':'Perbesar Smart Insight');}
  expand.addEventListener('click',function(){expanded(!section.classList.contains('is-expanded'));});section.addEventListener('keydown',function(e){if(e.key==='Escape'){expanded(false);expand.focus();}});
 });
 document.querySelectorAll('.le-official-track').forEach(function(track){
  var originals=Array.from(track.querySelectorAll('.le-official')),button=track.parentElement.querySelector('.le-official-pause'),reduced=matchMedia('(prefers-reduced-motion:reduce)'),manual=false,lastWidth=0;
  if(originals.length<2)return;
  function clone(node){var copy=node.cloneNode(true);copy.setAttribute('aria-hidden','true');copy.inert=true;copy.querySelectorAll('[id]').forEach(function(n){n.removeAttribute('id');});return copy;}
  function build(){
   track.replaceChildren.apply(track,originals);track.classList.remove('is-marquee');button.hidden=true;
   if(reduced.matches)return;
   var belt=document.createElement('div'),group=document.createElement('div');belt.className='le-official-belt';group.className='le-official-group';originals.forEach(function(card){group.appendChild(card);});belt.appendChild(group);track.appendChild(belt);track.classList.add('is-marquee');
   while(group.getBoundingClientRect().width<track.clientWidth){originals.forEach(function(card){group.appendChild(clone(card));});}
   var width=group.getBoundingClientRect().width;belt.appendChild(clone(group));belt.style.setProperty('--le-official-width',width+'px');belt.style.setProperty('--le-official-duration',(width/18)+'s');button.hidden=false;
  }
  button.addEventListener('click',function(){manual=!manual;track.classList.toggle('is-paused',manual);button.textContent=manual?'Putar animasi':'Jeda animasi';button.setAttribute('aria-pressed',String(manual));});
  track.addEventListener('touchstart',function(){track.classList.add('is-paused');},{passive:true});track.addEventListener('touchend',function(){if(!manual)track.classList.remove('is-paused');},{passive:true});track.addEventListener('touchcancel',function(){if(!manual)track.classList.remove('is-paused');},{passive:true});
  document.addEventListener('visibilitychange',function(){track.classList.toggle('is-hidden',document.hidden);});
  reduced.addEventListener('change',build);build();
  if(window.ResizeObserver)new ResizeObserver(function(entries){var w=Math.round(entries[0].contentRect.width);if(w!==lastWidth){lastWidth=w;build();}}).observe(track);
 });
});
