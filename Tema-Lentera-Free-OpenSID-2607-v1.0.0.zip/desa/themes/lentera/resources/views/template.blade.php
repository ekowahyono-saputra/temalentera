<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    @include('theme::commons.meta')
    <link rel="stylesheet" href="{{ base_url(theme_active()->asset_path . '/css/lentera.css?v=free-1.0.0') }}">
</head>
<body class="lentera">
@include('theme::lentera.loading')
<a class="le-skip" href="#le-main">Lewati ke isi halaman</a>
@php
    $leArticlePage = !empty($single_artikel['id']);
    $leBudgetPage = get_instance()->input->get('lentera_page') === 'apbdes';
    $leUri = trim((string) get_instance()->uri->uri_string(), '/');
    $leHome = in_array($leUri, ['', 'first', 'first/index'], true) && empty($cari) && ! $leBudgetPage && ! $leArticlePage;
@endphp
@include('theme::lentera.topbar')
<div class="le-wrap le-shell">
    <header id="header">@include('theme::partials.header')</header>
    @if (!$leArticlePage) @include('theme::lentera.hero') @endif
    <div id="navarea">@include('theme::partials.menu_head')</div>
    @if ($leHome)
        @include('theme::lentera.informasi')
        @include('theme::lentera.slider')
        @include('theme::lentera.shortcuts')
        @include('theme::lentera.bmkg')
    @endif
    <main id="le-main" tabindex="-1">@if ($leBudgetPage) @include('theme::lentera.apbdes-page') @else @yield('layout') @endif</main>
    @if ($leHome)
        @include('theme::lentera.aparatur')
        @include('theme::lentera.statistik')
        @include('theme::lentera.insight')
    @endif
</div>
<footer id="footer">
    @include('theme::partials.footer_top')
    @include('theme::partials.footer_bottom')
</footer>
@include('theme::lentera.mobile-nav')
@if (theme_config('lentera_wa_contact', '1') == '1')
    @include('theme::lentera.whatsapp')
@endif
@include('theme::commons.meta_footer')
<script src="{{ base_url(theme_active()->asset_path . '/js/lentera.js?v=free-1.0.0') }}" defer></script>
<script>
function formatRupiah(angka,prefix='Rp '){return prefix+Number(String(angka).replace(/[^\d.-]/g,'')).toLocaleString('id-ID',{minimumFractionDigits:2});}
if(typeof renderDate==='function'){renderDate();}
</script>
<script src="{{ base_url(theme_active()->asset_path . '/js/lentera-services.js?v=free-1.0.0') }}" defer></script>
@stack('scripts')
</body>
</html>
