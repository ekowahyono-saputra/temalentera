@php
 $leWaIcon = asset('front/wa.png');
 foreach (($sosmed ?? []) as $leSocial) {
  if (strcasecmp(trim((string)($leSocial['nama'] ?? '')), 'WhatsApp') === 0 && !empty($leSocial['icon'])) { $leWaIcon = $leSocial['icon']; break; }
 }
 $leContact = preg_replace('/[^0-9]/', '', (string)($desa['hp_kontak'] ?? identitas('hp_kontak') ?? ''));
 if (substr($leContact, 0, 1) === '0') $leContact = '62' . substr($leContact, 1);
 elseif (substr($leContact, 0, 1) === '8') $leContact = '62' . $leContact;
@endphp
@if (preg_match('/^62[0-9]{8,13}$/D', $leContact))
<a class="le-wa le-wa-floating le-wa-direct" href="https://wa.me/{{ $leContact }}" target="_blank" rel="noopener noreferrer" aria-label="Hubungi WhatsApp desa" title="WhatsApp Desa">
 <img class="le-wa-native-logo" src="{{ $leWaIcon }}" alt="" width="38" height="38" decoding="async">
 <span class="le-wa-tooltip" aria-hidden="true">WhatsApp Desa</span>
</a>
@endif
