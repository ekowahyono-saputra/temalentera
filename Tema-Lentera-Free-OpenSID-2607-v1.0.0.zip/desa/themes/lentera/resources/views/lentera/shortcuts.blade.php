@php
$leLinks = [
 ['data-wilayah','map-marker','Data Wilayah','Populasi per wilayah'],
 ['lapak','shopping-cart','Lapak Desa','Hasil olahan warga'],
 ['data-statistik/golongan-darah','tint','Golongan Darah','Data statistik'],
 ['pemerintah','desktop','Pemerintah Desa','Kenali aparatur desa'],
 ['pembangunan','building','Pembangunan','Dokumentasi kegiatan'],
 ['peraturan-desa','file-text-o','Produk Hukum','Peraturan desa'],
 ['data-dpt','check-square-o','DPT','Calon pemilih'],
 ['pengaduan','comments-o','Pengaduan','Partisipasi warga'],
 ['galeri','picture-o','Galeri','Album foto'],
 ['status-sdgs','globe','Status SDGs','Tujuan pembangunan'],
 ['peta','map-marker','Peta','Wilayah desa'],
 ['data-statistik/bantuan-penduduk','heart','Bantuan','Penerima manfaat']
];
@endphp
<section id="le-layanan" class="le-shortcuts" aria-label="Pintasan layanan">
 @foreach ($leLinks as [$url,$icon,$title,$desc])
 <a class="le-shortcut" href="{{ site_url($url) }}"><span class="le-icon tone-{{ $loop->index % 4 }}"><i class="fa fa-{{ $icon }}" aria-hidden="true"></i></span><span><strong>{{ $title }}</strong><small>{{ $desc }}</small></span><i class="fa fa-angle-right" aria-hidden="true"></i></a>
 @endforeach
</section>
