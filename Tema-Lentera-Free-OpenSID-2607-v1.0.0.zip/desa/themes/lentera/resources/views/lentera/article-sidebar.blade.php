<section class="le-news-widget">
<h2>Jelajahi Artikel</h2>
<div class="le-news-tabs" role="tablist" aria-label="Pilihan artikel">
 @foreach (['terkini'=>'Terbaru','populer'=>'Populer','acak'=>'Acak'] as $leKey=>$leLabel)
 <button type="button" role="tab" id="le-tab-{{ $leKey }}" aria-controls="le-posts-{{ $leKey }}" aria-selected="{{ $loop->first ? 'true' : 'false' }}" tabindex="{{ $loop->first ? '0' : '-1' }}" data-news-tab="{{ $leKey }}">{{ $leLabel }}</button>
 @endforeach
</div>
@foreach (['terkini'=>($arsip_terkini ?? []),'populer'=>($arsip_populer ?? []),'acak'=>($arsip_acak ?? [])] as $leKey=>$lePosts)
<div id="le-posts-{{ $leKey }}" role="tabpanel" aria-labelledby="le-tab-{{ $leKey }}" class="le-news-posts">
 @forelse ($lePosts as $lePost)
 @break($loop->index >= 5)
 <a class="le-news-mini" href="{{ site_url('artikel/' . buat_slug($lePost)) }}">
 @if (!empty($lePost['gambar']))<img src="{{ AmbilFotoArtikel($lePost['gambar'], 'sedang') }}" alt="" loading="lazy">@endif
 <span><strong>{{ $lePost['judul'] }}</strong><small>{{ tgl_indo($lePost['tgl_upload']) }}</small></span>
 </a>
 @empty<p class="le-news-empty">Belum ada artikel.</p>@endforelse
</div>
@endforeach
</section>
@include('theme::widgets.menu_kategori', ['judul_widget'=>'Kategori Artikel', 'menu_kiri'=>$menu_kiri ?? []])
@include('theme::widgets.sinergi_program', ['judul_widget'=>'Sinergi Program'])
