@foreach (($leMenuItems ?? []) as $leMenuItem)
<li class="{{ !empty($leMenuItem['childrens']) ? 'dropdown' : '' }}">
 <a href="{{ $leMenuItem['link_url'] ?? '#' }}" @if (!empty($leMenuItem['childrens'])) class="dropdown-toggle" aria-haspopup="true" aria-expanded="false" @endif>{{ $leMenuItem['nama'] ?? '' }}</a>
 @if (!empty($leMenuItem['childrens']))
 <ul class="dropdown-menu">@include('theme::lentera.menu-items', ['leMenuItems' => $leMenuItem['childrens']])</ul>
 @endif
</li>
@endforeach
