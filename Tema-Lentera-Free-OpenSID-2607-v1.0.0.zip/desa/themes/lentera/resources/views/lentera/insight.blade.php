@if (theme_config('lentera_smart_insight', '1') == '1')
@php
 // Aggregate-only reads. Village-specific cache, no browser polling or personal records.
 $leInsight = ['population'=>null, 'events'=>null, 'letters'=>null, 'history'=>null, 'letter_detail'=>null, 'articles'=>null, 'at'=>null];
 try {
  $leVillageId = (int) identitas('id');
  if ($leVillageId > 0) {
   $leInsight = cache()->remember('lentera_insight_v115_' . $leVillageId . '_' . date('Y-m-d'), 600, static function () use ($leVillageId) {
    $result = ['population'=>null, 'events'=>null, 'letters'=>null, 'history'=>null, 'letter_detail'=>null, 'articles'=>null, 'at'=>date('d/m/Y H:i')];
    $today = date('Y-m-d');
    $start = date('Y-m-01');
    $previous = date('Y-m-01', strtotime($start . ' -1 month'));
    $tomorrow = date('Y-m-d', strtotime($today . ' +1 day'));
    try {
     $result['population'] = (array) \Illuminate\Support\Facades\DB::table('tweb_penduduk')->where('config_id', $leVillageId)->where('status_dasar', 1)
      ->selectRaw('COUNT(*) AS total, COALESCE(SUM(CASE WHEN tanggallahir <= ? AND TIMESTAMPDIFF(YEAR, tanggallahir, ?) BETWEEN 15 AND 64 THEN 1 ELSE 0 END),0) AS productive, COALESCE(SUM(CASE WHEN tanggallahir <= ? AND TIMESTAMPDIFF(YEAR, tanggallahir, ?) BETWEEN 65 AND 150 THEN 1 ELSE 0 END),0) AS elderly, COALESCE(SUM(CASE WHEN tanggallahir <= ? AND TIMESTAMPDIFF(YEAR, tanggallahir, ?) BETWEEN 0 AND 14 THEN 1 ELSE 0 END),0) AS young', [$today, $today, $today, $today, $today, $today])->first();
    } catch (\Throwable $e) { /* Schema unavailable: preserve the page and show unknown. */ }
    try {
     // Only daily counts leave the database, never population identities.
     $rows = \Illuminate\Support\Facades\DB::table('log_penduduk')->where('config_id', $leVillageId)->where('tgl_peristiwa', '>=', '1900-01-01')->where('tgl_peristiwa', '<', $tomorrow)->whereIn('kode_peristiwa', [1,2,3,5])
      ->selectRaw('DATE(tgl_peristiwa) AS day, kode_peristiwa AS code, COUNT(*) AS n')->groupByRaw('DATE(tgl_peristiwa), kode_peristiwa')->orderBy('day')->get();
     $result['history'] = []; $result['events'] = array_fill_keys([1,2,3,5], [0,0]);
     foreach ($rows as $row) {
      $result['history'][] = ['day'=>$row->day, 'code'=>(int)$row->code, 'n'=>(int)$row->n];
      if ($row->day >= $start) $result['events'][(int)$row->code][0] += (int)$row->n;
      elseif ($row->day >= $previous) $result['events'][(int)$row->code][1] += (int)$row->n;
     }
    } catch (\Throwable $e) { }
    try {
     $letterQuery = \Illuminate\Support\Facades\DB::table('log_surat AS l')->where('l.config_id', $leVillageId)->whereNull('l.deleted_at')->where('l.status', 1)->where('l.tanggal', '>=', '1900-01-01')->where('l.tanggal', '<', $tomorrow);
     $daily = (clone $letterQuery)->selectRaw('DATE(l.tanggal) AS day, COUNT(*) AS n')->groupByRaw('DATE(l.tanggal)')->orderBy('day')->get();
     $result['letter_detail'] = ['daily'=>[], 'latest'=>null, 'popular'=>null]; $result['letters'] = 0;
     foreach ($daily as $row) { $result['letter_detail']['daily'][] = ['day'=>$row->day,'n'=>(int)$row->n]; if ($row->day >= $start) $result['letters'] += (int)$row->n; }
     // Format names are generic; never expose filenames, applicant names, NIK or document links.
     $named = (clone $letterQuery)->leftJoin('tweb_surat_format AS f', function ($join) use ($leVillageId) { $join->on('f.id','=','l.id_format_surat')->where('f.config_id', '=', $leVillageId); });
     $result['letter_detail']['latest'] = (clone $named)->select('f.nama AS name','l.tanggal AS date')->orderByDesc('l.tanggal')->orderByDesc('l.id')->limit(5)->get()->map(static fn ($row) => ['name'=>$row->name ?: 'Layanan surat','date'=>$row->date])->all();
     $result['letter_detail']['popular'] = (clone $named)->selectRaw('f.nama AS name, COUNT(*) AS n')->groupBy('f.nama')->orderByDesc('n')->orderBy('f.nama')->limit(5)->get()->map(static fn ($row) => ['name'=>$row->name ?: 'Layanan surat','n'=>(int)$row->n])->all();
    } catch (\Throwable $e) { }
    try {
     $articleQuery = \Illuminate\Support\Facades\DB::table('artikel')->where('config_id', $leVillageId)->whereNotIn('tipe', ['statis','agenda','keuangan']);
     $totalArticles = (clone $articleQuery)->count();
     $activeQuery = (clone $articleQuery)->where('enabled', 1)->where('tgl_upload','>=','1900-01-01')->where('tgl_upload','<=', date('Y-m-d H:i:s'));
     $activeArticles = (clone $activeQuery)->count();
     $monthly = (clone $activeQuery)->selectRaw("DATE_FORMAT(tgl_upload, '%Y-%m') AS month, COUNT(*) AS n, MIN(tgl_upload) AS first_date, MAX(tgl_upload) AS last_date")->groupByRaw("DATE_FORMAT(tgl_upload, '%Y-%m')")->orderBy('month')->get();
     $result['articles'] = ['total'=>$totalArticles,'active'=>$activeArticles,'monthly'=>[], 'first'=>null, 'last'=>null];
     foreach ($monthly as $row) { $result['articles']['monthly'][] = ['month'=>$row->month,'n'=>(int)$row->n]; $result['articles']['first'] ??= $row->first_date; $result['articles']['last'] = $row->last_date; }
    } catch (\Throwable $e) { }
    return $result;
   });
  }
 } catch (\Throwable $e) { /* Cache failure must not blank the homepage. */ }
 $lePop = $leInsight['population']; $leEvents = $leInsight['events'];
 $leFormat = static fn ($n) => $n === null ? '—' : number_format((float)$n, 0, ',', '.');
 $lePercent = static fn ($n) => $lePop && $lePop['total'] > 0 ? number_format(100 * $n / $lePop['total'], 1, ',', '.') . '%' : '—';
 $leGrowth = $leEvents === null ? null : $leEvents[1][0] + $leEvents[5][0] - $leEvents[2][0] - $leEvents[3][0];
 $lePreviousGrowth = $leEvents === null ? null : $leEvents[1][1] + $leEvents[5][1] - $leEvents[2][1] - $leEvents[3][1];
 $leTabs = ['ringkasan'=>'Ringkasan','grafik'=>'Grafik','analitik'=>'Analitik','surat'=>'Surat','artikel'=>'Artikel'];
@endphp
<section class="le-insight" aria-labelledby="le-insight-heading">
 <header class="le-insight-heading"><h2 id="le-insight-heading">SMART INSIGHT {{ strtoupper(setting('sebutan_desa')) }} {{ strtoupper($desa['nama_desa'] ?? '') }}</h2><button type="button" data-insight-expand aria-label="Perbesar Smart Insight" aria-expanded="false"><i class="fa fa-expand" aria-hidden="true"></i></button></header>
 <div class="le-insight-tabs" aria-label="Pilihan Smart Insight">
 @foreach ($leTabs as $key=>$label)<button type="button" data-insight-tab="{{ $key }}" id="le-insight-tab-{{ $key }}" aria-controls="le-insight-{{ $key }}">{{ $label }}</button>@endforeach
 </div>
 <div id="le-insight-ringkasan" class="le-insight-panel" aria-labelledby="le-insight-tab-ringkasan">
 <div class="le-insight-cards">
 @foreach ([['users','Total',$leFormat($lePop['total'] ?? null),'Jiwa','Penduduk berstatus hidup'],['user','Produktif',$lePercent($lePop['productive'] ?? 0),$leFormat($lePop['productive'] ?? null).' jiwa','Usia 15–64 tahun'],['heart','Lansia',$lePercent($lePop['elderly'] ?? 0),$leFormat($lePop['elderly'] ?? null).' jiwa','Usia 65 tahun ke atas'],['line-chart','Tumbuh',$leFormat($leGrowth),'Jiwa bulan ini','Berdasarkan peristiwa tercatat']] as [$icon,$label,$value,$unit,$note])
 <article class="le-insight-card"><h3><i class="fa fa-{{ $icon }}" aria-hidden="true"></i> {{ $label }}</h3><strong>{{ $value }}</strong><span>{{ $unit }}</span><small>{{ $note }}</small></article>
 @endforeach
 </div>
 <div class="le-insight-columns">
 <div><h3>PERKEMBANGAN PENDUDUK</h3><p class="le-insight-note">Bulan ini sampai hari ini dibandingkan seluruh bulan lalu.</p>
 <div class="le-insight-table"><table><thead><tr><th>Kategori</th><th>Bulan ini<br><small>{{ date('m/Y') }}</small></th><th>Bulan lalu<br><small>{{ date('m/Y', strtotime(date('Y-m-01').' -1 month')) }}</small></th><th>Perubahan</th></tr></thead><tbody>
 @foreach ([1=>'Kelahiran',2=>'Kematian',5=>'Masuk',3=>'Pindah'] as $code=>$label)
 <tr><th scope="row">{{ $label }}</th><td>{{ $leFormat($leEvents[$code][0] ?? null) }}</td><td>{{ $leFormat($leEvents[$code][1] ?? null) }}</td><td>{{ $leEvents === null ? '—' : sprintf('%+d', $leEvents[$code][0] - $leEvents[$code][1]) }}</td></tr>
 @endforeach
 <tr class="le-insight-total"><th scope="row">Pertumbuhan tercatat</th><td>{{ $leFormat($leGrowth) }}</td><td>{{ $leFormat($lePreviousGrowth) }}</td><td>{{ $leGrowth === null ? '—' : sprintf('%+d', $leGrowth-$lePreviousGrowth) }}</td></tr>
 </tbody></table></div></div>
 <aside><h3>INSIGHT CEPAT</h3><ul class="le-insight-facts">
 @if ($leGrowth !== null)<li>Perubahan bersih dari kelahiran, kematian, masuk dan pindah bulan ini: <strong>{{ $leFormat($leGrowth) }} jiwa</strong>.</li>@else<li>Data perkembangan penduduk belum tersedia.</li>@endif
 @if ($lePop)<li>Penduduk usia produktif: <strong>{{ $lePercent($lePop['productive']) }}</strong> dari total penduduk.</li><li>Penduduk lansia: <strong>{{ $leFormat($lePop['elderly']) }} jiwa</strong>. Kelompok lansia pada panel ini menggunakan usia 65 tahun ke atas, sesuai distribusi grafik.</li>@else<li>Data kelompok umur belum tersedia.</li>@endif
 <li>Surat tercetak bulan ini: <strong>{{ $leFormat($leInsight['letters']) }}</strong>{{ $leInsight['letters'] === null ? ' (belum tersedia)' : ' dokumen' }}.</li>
 </ul></aside>
 </div>
 </div>
 @include('theme::lentera.insight-panels')
 <p class="le-insight-note">Ringkasan otomatis dari data OpenSID · {{ $leInsight['at'] ? 'Dihitung '.$leInsight['at'].' · cache hingga 10 menit' : 'Data sementara belum tersedia' }}. Tanda — berarti data belum tersedia.</p>
 <script type="application/json" id="le-insight-data">{!! json_encode(['today'=>date('Y-m-d'),'population'=>$lePop,'events'=>$leInsight['history'],'letters'=>$leInsight['letter_detail'],'articles'=>$leInsight['articles']], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) !!}</script>
 <script defer src="{{ base_url(theme_active()->asset_path . '/js/lentera-insight.js?v=free-1.0.0') }}"></script>
</section>
@endif
