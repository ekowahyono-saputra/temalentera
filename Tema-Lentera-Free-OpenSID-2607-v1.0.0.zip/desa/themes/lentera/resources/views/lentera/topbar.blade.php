<div class="le-topbar">
 <div class="le-wrap">
  <span class="le-site-label"><i class="fa fa-check-circle" aria-hidden="true"></i> Website Resmi Pemerintah {{ ucwords(setting('sebutan_desa')) }}</span>
  <div class="le-live-clock" data-timezone="{{ setting('timezone') ?: date_default_timezone_get() }}">
   <i class="fa fa-clock-o" aria-hidden="true"></i>
   <time datetime="{{ date('c') }}" aria-live="off"><span class="le-clock-date">{{ date('d-m-Y') }}</span><strong class="le-clock-time">{{ date('H:i:s') }}</strong><small class="le-clock-zone"></small></time>
  </div>
  <div class="le-top-actions">
   <a href="{{ site_url('layanan-mandiri') }}" aria-label="Layanan Mandiri" title="Layanan Mandiri"><i class="fa fa-user" aria-hidden="true"></i><span>Layanan Mandiri</span></a>
   <a href="{{ site_url('siteman') }}" aria-label="Login Admin" title="Login Admin"><i class="fa fa-lock" aria-hidden="true"></i><span>Login Admin</span></a>
  </div>
 </div>
</div>
