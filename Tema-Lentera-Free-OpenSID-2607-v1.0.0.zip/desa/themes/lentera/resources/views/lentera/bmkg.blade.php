@if (theme_config('lentera_cuaca','1') == '1' || theme_config('lentera_gempa','1') == '1')
@php
 $leWeather=null; $leQuake=null; $leForecast=null;
 $leAdm4=trim((string)theme_config('lentera_bmkg_adm4',''));
 try {
  if (is_file(APPPATH . 'libraries/Lentera_service.php')) {
   require_once APPPATH . 'libraries/Lentera_service.php';
   if (theme_config('lentera_cuaca','1') == '1') $leWeather=\Lentera_service::bmkg('weather',$leAdm4);
   if (theme_config('lentera_gempa','1') == '1') $leQuake=\Lentera_service::bmkg('quake');
  }
  $leCandidates=[];
  foreach (($leWeather['data']['data'][0]['cuaca'] ?? []) as $leDay) foreach ($leDay as $leItem) {
   $leAt=strtotime(($leItem['utc_datetime'] ?? '') . ' UTC');
   if ($leAt && $leAt >= time()-10800) $leCandidates[$leAt]=$leItem;
  }
  ksort($leCandidates); $leForecast=$leCandidates ? reset($leCandidates) : null;
 } catch (\Throwable $e) { /* Keep homepage usable when upstream or cache is unavailable. */ }
 $leEvent=$leQuake['data']['Infogempa']['gempa'] ?? null;
@endphp
<section class="le-bmkg" aria-label="Informasi cuaca dan gempa">
 @if (theme_config('lentera_cuaca','1') == '1')
 <article class="le-bmkg-card le-weather"><span class="le-service-icon le-cloud-scene" aria-hidden="true"><svg viewBox="0 0 48 48" focusable="false"><circle class="le-weather-sun" cx="33" cy="14" r="8" fill="#ffc45d"/><path class="le-cloud-back" d="M16 23a7 7 0 0 1 7-7 9 9 0 0 1 17 3 6 6 0 0 1-1 12H18a4 4 0 0 1-2-8Z" fill="#9dccf1"/><path class="le-cloud-front" d="M9 27a8 8 0 0 1 15-4 7 7 0 0 1 9 6 6 6 0 0 1-1 12H11a7 7 0 0 1-2-14Z" fill="#fff" stroke="#c9e5f6" stroke-width="1.2"/></svg></span><div><span class="le-service-eyebrow">PRAKIRAAN CUACA DESA</span><h2>{{ $leWeather['data']['lokasi']['desa'] ?? 'Cuaca wilayah desa' }}</h2>
 @if ($leForecast)
 <strong class="le-service-number">{{ $leForecast['t'] ?? '—' }}°C</strong><p>{{ $leForecast['weather_desc'] ?? '—' }} · Kelembapan {{ $leForecast['hu'] ?? '—' }}%</p>
 <p>Angin {{ $leForecast['ws'] ?? '—' }} km/jam</p><small>Berlaku: {{ $leForecast['local_datetime'] ?? '—' }} (waktu lokal)</small>
 @else <p>{{ $leAdm4 ? 'Prakiraan belum tersedia. Silakan cek kembali nanti.' : 'Lokasi cuaca belum diatur oleh admin.' }}</p> @endif
 @if ($leWeather && $leWeather['stale'])<p class="le-cache-note">Data tersimpan; pembaruan sedang tidak tersedia.</p>@endif
 <a href="https://data.bmkg.go.id/prakiraan-cuaca/" target="_blank" rel="noopener">Sumber: BMKG ↗</a></div></article>
 @endif
 @if (theme_config('lentera_gempa','1') == '1')
 <article class="le-bmkg-card le-quake"><span class="le-service-icon le-quake-scene" aria-hidden="true"><svg viewBox="0 0 48 48" focusable="false"><g class="le-quake-building" fill="none" stroke="#b85715" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 35V12h18v23M21 35v-7h6v7M20 18h2m5 0h2m-9 5h2m5 0h2"/></g><path class="le-quake-ground" d="M5 38h12l4-3 4 6 4-3h14" fill="none" stroke="#d68a50" stroke-width="2" stroke-linecap="round"/><g class="le-quake-waves" fill="none" stroke="#e8ae79" stroke-width="1.6" stroke-linecap="round"><path d="M9 20a12 12 0 0 0 0 10M39 20a12 12 0 0 1 0 10"/></g></svg></span><div><span class="le-service-eyebrow">GEMPA TERBARU INDONESIA</span><h2>Informasi gempa</h2>
 @if ($leEvent)
 <strong class="le-service-number">M {{ $leEvent['Magnitude'] ?? '—' }}</strong><p>{{ $leEvent['Wilayah'] ?? '—' }}</p><p>Kedalaman {{ $leEvent['Kedalaman'] ?? '—' }} · {{ $leEvent['Tanggal'] ?? '' }} {{ $leEvent['Jam'] ?? '' }}</p><p>{{ $leEvent['Potensi'] ?? '' }}</p>
 @else <p>Informasi gempa belum tersedia. Periksa informasi resmi BMKG.</p> @endif
 @if ($leQuake && $leQuake['stale'])<p class="le-cache-note">Data tersimpan; pembaruan sedang tidak tersedia.</p>@endif
 <small>Informasi kejadian nasional, bukan peringatan dini lokasi desa.</small><a href="https://data.bmkg.go.id/gempabumi/" target="_blank" rel="noopener">Sumber: BMKG ↗</a></div></article>
 @endif
</section>
@endif
