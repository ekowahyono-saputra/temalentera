<section class="le-apbdes-page">
 <div class="le-section-title"><div><span class="le-kicker">TRANSPARANSI KEUANGAN</span><h2>Rincian APBDes {{ $transparansi['tahun'] ?? '' }}</h2></div><a href="{{ site_url() }}">Kembali ke beranda</a></div>
 @if (!empty($transparansi['data_widget']))
  @include('theme::partials.apbdesa-tema', $transparansi)
  <h3 class="le-apbdes-detail-title">Rincian anggaran dan realisasi</h3>
  @include('theme::partials.apbdesa-detail', $transparansi)
 @else
  <div class="le-empty"><h3>Data anggaran belum tersedia</h3><p>Data APBDes akan ditampilkan setelah dipublikasikan oleh pemerintah desa.</p></div>
 @endif
</section>
