<div id="le-insight-grafik" class="le-insight-panel" aria-labelledby="le-insight-tab-grafik">
 <div class="le-insight-columns le-insight-visual-grid">
  <div><div class="le-si-heading"><h3>PERKEMBANGAN PENDUDUK</h3>@include('theme::lentera.insight-range', ['rangeTarget'=>'population'])</div>
   <button type="button" class="le-si-button" data-chart-download="population">↓ Download Grafik JPG</button>
   <div class="le-si-chart" data-chart="population" aria-label="Grafik perkembangan penduduk"></div>
   <details class="le-si-data"><summary>Lihat data grafik</summary><div class="le-insight-table" data-chart-table="population"></div></details>
  </div>
  <aside><h3>DISTRIBUSI USIA</h3><p class="le-si-subtitle">DISTRIBUSI USIA PENDUDUK</p><div class="le-si-age" data-age-chart></div><ul class="le-si-age-legend" data-age-legend></ul><button type="button" class="le-si-button" data-age-toggle aria-pressed="false">Tampilan 3D (Doughnut)</button></aside>
 </div>
</div>
<div id="le-insight-analitik" class="le-insight-panel" aria-labelledby="le-insight-tab-analitik">
 <h3>ANALITIK PERKEMBANGAN</h3><p>Telusuri perubahan penduduk berdasarkan tahun, bulan, atau rentang waktu.</p>
 <form class="le-si-filters" data-analysis-form>
  <label>Jenis grafik<select name="mode"><option value="events">Peristiwa</option><option value="growth">Pertumbuhan bersih</option></select></label>
  <label>Tahun<select name="year"><option value="">Semua Tahun</option></select></label>
  <label>Bulan<select name="month"><option value="">Semua Bulan</option>@foreach (['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'] as $month)<option value="{{ sprintf('%02d', $loop->iteration) }}">{{ $month }}</option>@endforeach</select></label>
  <label>Dari tanggal<input name="start" type="date" min="1900-01-01" max="{{ date('Y-m-d') }}"></label>
  <label>Sampai tanggal<input name="end" type="date" min="1900-01-01" max="{{ date('Y-m-d') }}"></label>
  <button type="submit" class="le-si-button le-si-primary">Terapkan</button><button type="button" class="le-si-button le-si-primary" data-analysis-csv>CSV</button>
 </form>
 <p class="le-si-message" data-analysis-message role="status" aria-live="polite"></p>
 <div class="le-si-insight-chips" data-analysis-summary></div>
 <div class="le-si-chart" data-chart="analysis" aria-label="Grafik analitik perkembangan"></div>
 <div class="le-insight-table le-si-analysis-table" tabindex="0" aria-label="Tabel analitik, geser untuk melihat semua kolom" data-analysis-table></div>
 <p class="le-insight-note">Tanggal, tahun, dan bulan diterapkan bersama. Pertumbuhan = lahir + masuk − mati − pindah. Kolom penduduk awal/akhir, jenis kelamin dan KK memerlukan snapshot historis; tanda — berarti snapshot belum tersedia. Angka nol berarti tidak ada peristiwa tercatat pada periode tersebut.</p>
</div>
<div id="le-insight-surat" class="le-insight-panel" aria-labelledby="le-insight-tab-surat">
 <div class="le-insight-columns le-insight-visual-grid">
  <div><h3>PERKEMBANGAN LAYANAN SURAT</h3><div class="le-insight-cards le-si-letter-cards">
  @foreach (['today'=>'Hari Ini','week'=>'Minggu Ini','month'=>'Bulan Ini','year'=>'Tahun Ini','yesterday'=>'Kemarin','lastweek'=>'Minggu Lalu','lastmonth'=>'Bulan Lalu','lastyear'=>'Tahun Lalu'] as $key=>$label)
   <article class="le-insight-card {{ $loop->index >= 4 ? 'le-si-blue' : '' }}"><h3>{{ $label }}</h3><strong data-letter-count="{{ $key }}">—</strong><span>Surat</span></article>
  @endforeach
  </div><article class="le-insight-card le-si-total-card"><h3>TOTAL SURAT TERCETAK</h3><strong data-letter-count="total">—</strong><span>Surat</span></article>
  <div class="le-si-heading"><h3>TREN LAYANAN SURAT</h3>@include('theme::lentera.insight-range', ['rangeTarget'=>'letters'])</div>
  <div class="le-si-chart" data-chart="letters" aria-label="Grafik tren layanan surat"></div>
  <details class="le-si-data"><summary>Lihat data grafik</summary><div class="le-insight-table" data-chart-table="letters"></div></details>
  <p class="le-insight-note">Surat berstatus cetak, tidak termasuk arsip yang dihapus. Minggu dimulai Senin; periode berjalan dihitung sampai hari ini. Daftar hanya menampilkan jenis dan waktu layanan.</p>
  </div>
  <aside><h3>5 SURAT TERBARU</h3><ul class="le-si-list" data-letter-latest></ul><h3>5 SURAT TERPOPULER</h3><ol class="le-si-list" data-letter-popular></ol></aside>
 </div>
</div>
<div id="le-insight-artikel" class="le-insight-panel" aria-labelledby="le-insight-tab-artikel">
 <div class="le-insight-columns le-insight-visual-grid">
  <div><h3>STATISTIK ARTIKEL</h3><div class="le-insight-cards le-si-article-cards"><article class="le-insight-card le-si-blue"><h3>Total Artikel</h3><strong data-article-count="total">—</strong><span>Dibuat</span></article><article class="le-insight-card"><h3>Aktif</h3><strong data-article-count="active">—</strong><span>Sudah terbit</span></article></div>
  <div class="le-si-heading"><h3>TREN ARTIKEL PER BULAN</h3>@include('theme::lentera.insight-range', ['rangeTarget'=>'articles'])</div><div class="le-si-chart" data-chart="articles" aria-label="Grafik tren artikel per bulan"></div>
  <details class="le-si-data"><summary>Lihat data grafik</summary><div class="le-insight-table" data-chart-table="articles"></div></details>
  <p class="le-insight-note">Total mencakup artikel aktif dan nonaktif desa ini; halaman statis, agenda dan keuangan dikecualikan. Grafik dan rentang posting menggunakan artikel aktif yang sudah terbit. Bulan tanpa posting ditampilkan nol.</p>
  </div>
  <aside><h3>RENTANG POSTING</h3><div class="le-si-list"><p><strong>Awal:</strong> <span data-article-date="first">—</span></p><p><strong>Terakhir:</strong> <span data-article-date="last">—</span></p></div><h3>5 BULAN TERAKHIR</h3><ol class="le-si-list" data-article-latest></ol><h3>5 BULAN TERAKTIF</h3><ol class="le-si-list" data-article-popular></ol></aside>
 </div>
</div>
<noscript><p>Aktifkan JavaScript untuk grafik interaktif dan filter. Ringkasan utama tetap dapat dibaca tanpa JavaScript.</p></noscript>
