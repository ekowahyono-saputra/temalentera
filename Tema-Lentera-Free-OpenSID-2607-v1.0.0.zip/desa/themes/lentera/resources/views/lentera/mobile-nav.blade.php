<nav class="le-mobile-nav" aria-label="Navigasi bawah">
 <a href="{{ site_url() }}"><i class="fa fa-home" aria-hidden="true"></i><span>Beranda</span></a>
 <a href="{{ site_url('arsip') }}"><i class="fa fa-newspaper-o" aria-hidden="true"></i><span>Berita</span></a>
 <a class="le-mobile-primary" href="{{ site_url('layanan-mandiri') }}"><i class="fa fa-user" aria-hidden="true"></i><span>Layanan</span></a>
 <a href="{{ site_url('pengaduan') }}"><i class="fa fa-comments-o" aria-hidden="true"></i><span>Aduan</span></a>
 <a href="{{ site_url() . '?lentera_page=apbdes' }}"><i class="fa fa-pie-chart" aria-hidden="true"></i><span>APBDes</span></a>
</nav>
