@php
 $leSlides = [];
 foreach (($slider_gambar['gambar'] ?? []) as $leImage) {
     $lePath = ($slider_gambar['lokasi'] ?? '') . 'sedang_' . ($leImage['gambar'] ?? '');
     if (!is_file($lePath)) $lePath = ($slider_gambar['lokasi'] ?? '') . ($leImage['gambar'] ?? '');
     if (empty($leImage['gambar']) || !is_file($lePath)) continue;
     $leSlides[] = [
         'src' => base_url($lePath),
         'title' => $leImage['judul'] ?? '',
         'url' => (int) ($slider_gambar['sumber'] ?? 3) === 3 ? site_url('galeri') : ci_route('artikel.' . buat_slug($leImage)),
     ];
 }
@endphp
@if (count($leSlides))
<section class="le-carousel" aria-label="Sorotan desa" aria-roledescription="carousel">
 <div class="le-slides" tabindex="0" aria-label="Geser untuk melihat sorotan berikutnya">
 @foreach ($leSlides as $leSlide)
  <a class="le-slide" href="{{ $leSlide['url'] }}" aria-label="{{ $leSlide['title'] ?: 'Lihat foto desa' }}">
   <img src="{{ $leSlide['src'] }}" alt="{{ $leSlide['title'] }}" loading="{{ $loop->first ? 'eager' : 'lazy' }}" decoding="async">
   <span class="le-slide-caption"><small>SOROTAN DESA</small><strong>{{ $leSlide['title'] ?: 'Potret kegiatan desa' }}</strong></span>
  </a>
 @endforeach
 </div>
 @if (count($leSlides) > 1)
 <div class="le-slide-controls"><button type="button" data-slide="-1" aria-label="Slide sebelumnya"><i class="fa fa-angle-left" aria-hidden="true"></i></button><span class="le-slide-count" aria-live="polite">1 / {{ count($leSlides) }}</span><button type="button" data-slide="1" aria-label="Slide berikutnya"><i class="fa fa-angle-right" aria-hidden="true"></i></button><button type="button" data-slide-play aria-label="Putar slider otomatis" aria-pressed="false"><i class="fa fa-play" aria-hidden="true"></i></button></div>
 @endif
</section>
@endif
