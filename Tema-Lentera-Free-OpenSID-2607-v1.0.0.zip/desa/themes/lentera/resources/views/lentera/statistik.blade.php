@if (theme_config('statistik_desa', '1') == '1')
@php
 $lePopulation = [];
 foreach (($stat_widget ?? []) as $leRow) {
  $leLabel = strtoupper(trim($leRow['nama'] ?? ''));
  if (in_array($leLabel, ['LAKI-LAKI','PEREMPUAN','JUMLAH'], true)) $lePopulation[$leLabel] = (int) ($leRow['jumlah'] ?? 0);
 }
 $leTotal = $lePopulation['JUMLAH'] ?? (isset($lePopulation['LAKI-LAKI'], $lePopulation['PEREMPUAN']) ? $lePopulation['LAKI-LAKI'] + $lePopulation['PEREMPUAN'] : null);
 $leStatLinks = [
 ['data-wilayah','map-marker','Wilayah'],
 ['data-statistik/pendidikan-dalam-kk','graduation-cap','Pendidikan'],
 ['data-statistik/pekerjaan','briefcase','Pekerjaan'],
 ['data-statistik/rentang-umur','users','Usia']
 ];
@endphp
<section class="le-population" aria-label="Statistik penduduk">
 <div class="le-population-heading"><span>STATISTIK</span><h2>{{ strtoupper(setting('sebutan_desa')) }}</h2></div>
 <div class="le-population-counts">
  <div class="le-population-sex">
  @foreach (['LAKI-LAKI' => 'male', 'PEREMPUAN' => 'female'] as $leLabel => $leIcon)
   <div class="le-population-person"><i class="fa fa-{{ $leIcon }}" aria-hidden="true"></i><strong>{{ isset($lePopulation[$leLabel]) ? number_format($lePopulation[$leLabel], 0, ',', '.') : '—' }}</strong><span>{{ strtolower($leLabel) }}</span></div>
  @endforeach
  </div>
  <p class="le-population-total">total <strong>{{ $leTotal !== null ? number_format($leTotal, 0, ',', '.') : '—' }}</strong> penduduk</p>
  @if (empty($lePopulation))<small>Data statistik belum tersedia.</small>@endif
 </div>
 <div class="le-population-links">
 @foreach ($leStatLinks as [$leUrl, $leIcon, $leLabel])
  <a class="le-population-ring le-ring-{{ $loop->index }}" href="{{ site_url($leUrl) }}"><span><i class="fa fa-{{ $leIcon }}" aria-hidden="true"></i><span>Data<br>{{ $leLabel }}</span></span></a>
 @endforeach
 </div>
</section>
@endif
