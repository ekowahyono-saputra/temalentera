@php
    $leLoginName = trim((string) ($leAdminOptions['lentera_login_nama'] ?? '')) ?: ($header['nama_kepala_desa'] ?? '');
    $leLoginPhoto = '';
    $leLoginPosition = setting('sebutan_kepala_desa') ?: 'Kepala ' . ucwords(setting('sebutan_desa'));
    try {
        // Use OpenSID's active village-scoped head and its official photo accessor.
        $leLoginHead = \App\Models\Pamong::kepalaDesa()
            ->addSelect(['tweb_desa_pamong.foto', 'tweb_desa_pamong.id_pend'])
            ->first();
        if ($leLoginHead) {
            $leHeadPhoto = $leLoginHead->foto_staff;
            if ($leHeadPhoto) $leLoginPhoto = AmbilFoto($leHeadPhoto, '');
            if (empty(trim((string) ($leAdminOptions['lentera_login_nama'] ?? '')))) {
                $leLoginName = $leLoginHead->pamong_nama ?: $leLoginName;
            }
            $leLoginPosition = $leLoginHead->pamong_jabatan ?: $leLoginPosition;
        }
    } catch (\Throwable $e) {
        // Missing personnel data must not prevent administrators from signing in.
        $leLoginPhoto = '';
    }
    $leLoginQuote = $leAdminOptions['lentera_login_sambutan'] ?? 'Mewujudkan tata kelola pemerintahan desa yang transparan, akuntabel, dan berbasis digital untuk kesejahteraan warga.';
@endphp
<aside class="le-admin-intro" aria-label="Profil pemerintah desa">
 <div class="le-admin-brand"><span class="le-admin-badge">PORTAL PEMERINTAH DESA</span><h2>Sistem Informasi Desa</h2><p>Pelayanan Digital Resmi {{ ucwords(setting('sebutan_desa')) }} {{ $header['nama_desa'] ?? '' }}</p></div>
 <div class="le-admin-profile">
  <div class="le-admin-portrait">
   @if ($leLoginPhoto)
    <img src="{{ $leLoginPhoto }}" alt="{{ $leLoginName ?: 'Kepala desa' }}" width="176" height="224">
   @else
    <svg viewBox="0 0 176 224" role="img" aria-label="Foto kepala desa belum diunggah"><rect width="176" height="224" rx="16" fill="#145749"/><circle cx="88" cy="76" r="33" fill="#b4d4c9"/><path d="M25 205v-29c0-40 126-40 126 0v29" fill="#b4d4c9"/></svg>
   @endif
   <span class="le-admin-profile-mark" aria-hidden="true">✓</span>
  </div>
  @if ($leLoginName)<h3>{{ $leLoginName }}</h3>@endif
  <p class="le-admin-position">{{ $leLoginPosition }} {{ $header['nama_desa'] ?? '' }}</p>
  @if ($leLoginQuote)<blockquote>“{{ $leLoginQuote }}”</blockquote>@endif
 </div>
 <footer>OpenSID {{ defined('VERSION') ? 'v' . ltrim((string) VERSION, 'vV') : 'v' . AmbilVersi() }} · © {{ date('Y') }} Pemerintah {{ ucwords(setting('sebutan_desa')) }} {{ $header['nama_desa'] ?? '' }}</footer>
</aside>
