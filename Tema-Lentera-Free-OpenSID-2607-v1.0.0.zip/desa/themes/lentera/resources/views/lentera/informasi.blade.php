<div class="le-announcement">
 <strong><i class="fa fa-bullhorn" aria-hidden="true"></i> Info Desa</strong>
 <div>@if (!empty($teks_berjalan))
 @include('theme::layouts.teks_berjalan')
 @else
 {{ theme_config('lentera_sambutan') ?: 'Selamat datang di website resmi desa. Akses informasi dan layanan desa dengan mudah.' }}
 @endif</div>
 <a href="{{ site_url('arsip') }}" aria-label="Arsip informasi"><i class="fa fa-list" aria-hidden="true"></i></a>
</div>
