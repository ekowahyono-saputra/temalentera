<section class="le-hero" aria-label="Identitas desa">
 @if (theme_config('lentera_sampul'))
 <img class="le-hero-photo" src="{{ base_url(theme_config('lentera_sampul')) }}" alt="" fetchpriority="high">
 @endif
 <div class="le-hero-content">
  <span class="le-eyebrow">{{ theme_config('lentera_judul') ?: 'WEBSITE RESMI PEMERINTAH DESA' }}</span>
  <h1>{{ ucwords(setting('sebutan_desa')) }} {{ $desa['nama_desa'] ?? '' }}</h1>
  <p>{{ ucwords(setting('sebutan_kecamatan_singkat')) }} {{ $desa['nama_kecamatan'] ?? '' }} · {{ ucwords(setting('sebutan_kabupaten_singkat')) }} {{ $desa['nama_kabupaten'] ?? '' }}<br>Provinsi {{ $desa['nama_propinsi'] ?? '' }}</p>
 </div>
</section>
