<section class="single_footer_top le-footer-visitors" aria-labelledby="le-footer-visitors-title">
 <h2 id="le-footer-visitors-title">Statistik Pengunjung</h2>
 <div class="le-visitor-panel">
  <div class="le-visitor-caption"><span class="le-visitor-icon" aria-hidden="true"><i class="fa fa-bar-chart"></i></span><span>Kunjungan Website</span></div>
  <dl class="le-visitor-values">
   @foreach (['hari_ini'=>'Hari Ini','kemarin'=>'Kemarin','total'=>'Total Kunjungan'] as $leVisitKey=>$leVisitLabel)
   <div class="le-visitor-value {{ $leVisitKey === 'total' ? 'le-visitor-total' : '' }}">
    <dt>{{ $leVisitLabel }}</dt>
    <dd>{{ isset($statistik_pengunjung[$leVisitKey]) && is_numeric($statistik_pengunjung[$leVisitKey]) ? number_format((float) $statistik_pengunjung[$leVisitKey], 0, ',', '.') : '—' }}</dd>
   </div>
   @endforeach
  </dl>
  @if (!isset($statistik_pengunjung['total']))<p class="le-visitor-empty">Statistik belum tersedia.</p>@endif
 </div>
</section>
