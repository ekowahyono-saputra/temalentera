<div class="le-si-ranges" role="group" aria-label="Rentang grafik {{ $rangeTarget }}" data-range-for="{{ $rangeTarget }}">
 @foreach (['2'=>'2 Bln','3'=>'3 Bln','6'=>'6 Bln','12'=>'1 Thn','24'=>'2 Thn','36'=>'3 Thn','60'=>'5 Thn','all'=>'Semua'] as $range=>$label)
 <button type="button" data-range="{{ $range }}" aria-pressed="{{ ($rangeTarget === 'articles' ? $range === 'all' : (string)$range === '6') ? 'true' : 'false' }}">{{ $label }}</button>
 @endforeach
</div>
