<div id="le-first-loading" hidden role="status" aria-live="polite" aria-label="Memuat website desa"><div class="le-loading-card"><div class="le-loading-emblem"><img src="{{ gambar_desa($desa['logo'] ?? '') }}" alt="" width="64" height="76"></div><span>Menyiapkan informasi desa</span><span class="le-loading-line" aria-hidden="true"></span></div></div>
<style>
#le-first-loading[hidden]{display:none!important}
#le-first-loading{position:fixed;inset:0;z-index:1100;display:grid;place-items:center;background:#f7f9fcf2;pointer-events:none;opacity:1;transition:opacity .28s ease,visibility .28s;animation:le-loading-expire 1.8s step-end forwards}
#le-first-loading.le-loading-done{opacity:0;visibility:hidden}
.le-loading-card{display:flex;flex-direction:column;align-items:center;gap:20px;padding:30px;border-radius:24px;background:#ffffffd9;box-shadow:0 15px 55px #29394f12;font:12px/1.5 "Segoe UI",Arial,sans-serif;color:#53627a}
.le-loading-emblem{position:relative;width:108px;height:108px;display:grid;place-items:center}
.le-loading-emblem:before{content:"";position:absolute;inset:0;border:2px solid #e7eaf1;border-top-color:#934b98;border-right-color:#277ca5;border-radius:50%;animation:le-loading-orbit 1.8s linear infinite}
#le-first-loading img{object-fit:contain;animation:le-loading-breathe 1.8s ease-in-out infinite}
.le-loading-line{height:3px;width:95px;border-radius:4px;background:linear-gradient(90deg,#a73d87,#2f759f);transform-origin:center;animation:le-loading-breathe 1.8s ease-in-out infinite}
@keyframes le-loading-breathe{50%{transform:scale(.95);opacity:.7}}
@keyframes le-loading-orbit{to{transform:rotate(360deg)}}
@keyframes le-loading-expire{to{visibility:hidden;opacity:0}}
@media(prefers-reduced-motion:reduce){#le-first-loading img,.le-loading-line,.le-loading-emblem:before{animation:none}#le-first-loading{transition:none}}
</style>
<script>
(function(){
 var loader=document.getElementById('le-first-loading');
 if(!loader)return;
 try{if(sessionStorage.getItem('lentera-visited')==='1')return;sessionStorage.setItem('lentera-visited','1');}catch(e){return;}
 var began=Date.now(),done=false,reduced=window.matchMedia('(prefers-reduced-motion:reduce)').matches;
 loader.hidden=false;
 function finish(){
  if(done)return;done=true;
  setTimeout(function(){loader.classList.add('le-loading-done');setTimeout(function(){loader.hidden=true;},reduced?0:280);},reduced?0:Math.max(0,260-(Date.now()-began)));
 }
 setTimeout(finish,1200);
 if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',finish,{once:true});}else{finish();}
 window.addEventListener('pageshow',finish,{once:true});
})();
</script>
