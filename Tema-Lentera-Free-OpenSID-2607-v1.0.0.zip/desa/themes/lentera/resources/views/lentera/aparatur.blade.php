@if (theme_config('lentera_aparatur', '1') == '1')
<section class="le-officials">
 <div class="le-section-title"><div><span class="le-kicker">MELAYANI DENGAN SEPENUH HATI</span><h2>Perangkat {{ ucwords(setting('sebutan_desa')) }}</h2></div><a href="{{ site_url('pemerintah') }}">Selengkapnya <i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
 <button type="button" class="le-official-pause" hidden>Jeda animasi</button>
 <div class="le-official-track" tabindex="0" aria-label="Foto perangkat desa, arahkan kursor untuk menjeda">
 @forelse (($aparatur_desa['daftar_perangkat'] ?? []) as $orang)
  <article class="le-official">
   @if (!empty($orang['foto']))<img src="{{ $orang['foto'] }}" alt="{{ $orang['nama'] ?? '' }}" loading="lazy">@else<div class="le-person-fallback"><i class="fa fa-user" aria-hidden="true"></i></div>@endif
   <div><h3>{{ $orang['nama'] ?? '' }}</h3><p>{{ $orang['jabatan'] ?? '' }}</p></div>
  </article>
 @empty
  <p class="le-empty-text">Informasi aparatur akan tampil setelah data perangkat desa dipublikasikan.</p>
 @endforelse
 </div>
</section>
@endif
