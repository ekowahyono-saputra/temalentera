@php defined('BASEPATH') || exit('No direct script access allowed'); @endphp

<script src="{{ base_url(theme_active()->asset_path . '/js/wow.min.js?v=free-1.0.0') }}"></script>
<script src="{{ base_url(theme_active()->asset_path . '/js/slick.min.js?v=free-1.0.0') }}"></script>
<script src="{{ base_url(theme_active()->asset_path . '/js/custom.js?v=free-1.0.0') }}"></script>
<script>
    $.extend($.fn.dataTable.defaults, {
        lengthMenu: [
            [10, 25, 50, 100, -1],
            [10, 25, 50, 100, "Semua"]
        ],
        pageLength: 10,
        language: {
            url: "{{ asset('bootstrap/js/dataTables.indonesian.lang') }}",
        }
    });
</script>
@if (!setting('inspect_element'))
    <script src="{{ asset('js/disabled.min.js') }}"></script>
@endif
