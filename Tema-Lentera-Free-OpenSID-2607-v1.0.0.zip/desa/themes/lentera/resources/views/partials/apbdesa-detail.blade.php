<div class="le-budget-details-grid">
@foreach (($data_widget ?? []) as $leGroup)
 <section class="le-budget-detail-group">
 <h3>{{ $leGroup['laporan'] ?? 'Rincian anggaran' }}</h3>
 @foreach ($leGroup as $leItem)
 @continue(!is_array($leItem) || empty($leItem['judul']))
 @php
  $leReal = (float) ($leItem['realisasi'] ?? 0);
  $lePlanDetail = (float) ($leItem['anggaran'] ?? 0);
  $lePct = $lePlanDetail > 0 ? round($leReal / $lePlanDetail * 100, 1) : 0;
 @endphp
 <div class="le-budget-detail-row">
  <h4>{{ \Illuminate\Support\Str::title($leItem['judul']) }}</h4>
  <dl><div><dt>Anggaran</dt><dd>Rp {{ number_format($lePlanDetail, 0, ',', '.') }}</dd></div><div><dt>Realisasi</dt><dd>Rp {{ number_format($leReal, 0, ',', '.') }}</dd></div></dl>
  <div class="le-budget-detail-meter"><span style="width:{{ max(0,min(100,$lePct)) }}%"></span></div>
  <small>{{ number_format($lePct, 1, ',', '.') }}% terealisasi</small>
 </div>
 @endforeach
 </section>
@endforeach
</div>
