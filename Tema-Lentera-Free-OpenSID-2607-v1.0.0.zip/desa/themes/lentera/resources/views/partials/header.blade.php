<div class="le-brandbar">
 <a class="le-brand" href="{{ site_url() }}">
  <img class="le-logo-motion le-logo-mode-{{ theme_config('lentera_putar_logo', '1') }}" src="{{ gambar_desa($desa['logo'] ?? '') }}" alt="Lambang {{ $desa['nama_desa'] ?? '' }}" width="56" height="64">
  <span><small>PEMERINTAH {{ strtoupper(setting('sebutan_desa')) }}</small><strong>{{ $desa['nama_desa'] ?? '' }}</strong><span>{{ ucwords(setting('sebutan_kecamatan_singkat')) }} {{ $desa['nama_kecamatan'] ?? '' }} · {{ ucwords(setting('sebutan_kabupaten_singkat')) }} {{ $desa['nama_kabupaten'] ?? '' }}</span></span>
 </a>
 <button class="le-search-toggle" type="button" aria-label="Buka pencarian" aria-expanded="false" aria-controls="le-search-form"><i class="fa fa-search" aria-hidden="true"></i></button>
 <form id="le-search-form" class="le-search" method="get" action="{{ site_url() }}" role="search">
  <label class="sr-only" for="le-search-input">Cari artikel desa</label>
  <input id="le-search-input" name="cari" type="search" maxlength="100" value="{{ $cari ?? '' }}" placeholder="Cari informasi desa…">
  <button type="submit" aria-label="Cari"><i class="fa fa-search" aria-hidden="true"></i></button>
 </form>
</div>
