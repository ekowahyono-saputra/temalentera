<div class="footer_bottom">
 <div class="container le-footer-credit">
  <span class="le-footer-owner">&copy; {{ date('Y') }} Pemerintah {{ ucwords(setting('sebutan_desa')) }} {{ $desa['nama_desa'] ?? '' }}</span>
  <span class="le-footer-powered">Ditenagai <a href="https://github.com/OpenSID/OpenSID" rel="noopener" target="_blank">OpenSID</a> <span class="le-opensid-version">{{ defined('VERSION') ? 'v' . ltrim((string) VERSION, 'vV') : '' }}</span> · Tema Lentera Free 1.0.0</span>
 </div>
</div>
<script>function printDiv(id){window.print();}</script>
