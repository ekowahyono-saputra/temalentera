@php defined('BASEPATH') || exit('No direct script access allowed'); @endphp

@if (empty($leBudgetPage) && isset($transparansi) && !is_null($transparansi))
    @include('theme::partials.apbdesa-tema', $transparansi)
@endif

<div class="footer_top">
    <div class="container">
        <div class="row le-footer-grid">
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="single_footer_top wow fadeInRight">
                    <div class="le-footer-identity"><img class="le-footer-emblem le-logo-motion le-logo-mode-{{ theme_config('lentera_putar_logo', '1') }}" src="{{ gambar_desa($desa['logo'] ?? '') }}" alt="Lambang {{ $desa['nama_desa'] ?? '' }}" width="58" height="68"><h2>{{ ucwords(setting('sebutan_desa')) }} {{ ucwords($desa['nama_desa']) }}</h2></div>
                    <p>{{ $desa['alamat_kantor'] }}<br>{{ ucwords(setting('sebutan_kecamatan') . ' ' . $desa['nama_kecamatan']) }} {{ ucwords(setting('sebutan_kabupaten') . ' ' . $desa['nama_kabupaten']) }} Provinsi {{ $desa['nama_propinsi'] }} Kode Pos {{ $desa['kode_pos'] }}</p>
                    <p>
                        @if (!empty($desa['email_desa']))
                            Email: {{ $desa['email_desa'] }}
                        @endif
                        <br />
                        @if (!empty($desa['telepon']))
                            Telp: {{ $desa['telepon'] }}
                        @endif
                    </p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="single_footer_top wow fadeInDown">
                    <h2>Kategori</h2>
                    <ul class="le-footer-links">
                        @foreach ($menu_kiri as $data)
                            <li><a href="{{ site_url('artikel/kategori/' . $data['slug']) }}">{{ $data['kategori'] }}</a></li>
                        @endforeach
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="single_footer_top"><h2>Tautan Cepat</h2>
                 <ul class="le-footer-links">
                  <li><a href="{{ site_url('layanan-mandiri') }}">Layanan Mandiri</a></li>
                  <li><a href="{{ site_url('pemerintah') }}">Perangkat Desa</a></li>
                  <li><a href="{{ site_url() . '?lentera_page=apbdes' }}">Transparansi APBDes</a></li>
                  <li><a href="{{ site_url('informasi-publik') }}">Informasi Publik</a></li>
                  <li><a href="{{ site_url('pengaduan') }}">Pengaduan</a></li>
                  <li><a href="{{ site_url('peta') }}">Peta Desa</a></li>
                 </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="single_footer_top wow fadeInRight">
                    <h2>Media Sosial</h2>
                    @if (setting('tte'))
                        <img src="{{ asset('assets/images/bsre.png?v', false) }}" alt="Bsre" class="img-responsive" style="width: 185px;" />
                    @endif
                    @foreach ($sosmed as $data)
                        @if (!empty($data['link']))
                            <a class="le-social-link" aria-label="{{ $data['nama'] }}" href="{{ $data['link'] }}" rel="noopener noreferrer" target="_blank">
                                <img src="{{ $data['icon'] }}" alt="{{ $data['nama'] }}" width="28" height="28" />
                            </a>
                        @endif
                    @endforeach
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 le-footer-visitors-column">
                @include('theme::lentera.footer-visitors')
            </div>
        </div>
    </div>
</div>
