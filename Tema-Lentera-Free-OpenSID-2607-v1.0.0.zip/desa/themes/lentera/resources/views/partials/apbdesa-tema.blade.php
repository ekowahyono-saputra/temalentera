@php
 $leBudget = [];
 foreach (($data_widget['res_pelaksanaan'] ?? []) as $leEntry) {
  if (!is_array($leEntry)) continue;
  $leTitle = strtoupper(trim($leEntry['judul'] ?? ''));
  if (in_array($leTitle, ['PENDAPATAN','BELANJA','PEMBIAYAAN'], true)) $leBudget[$leTitle] = $leEntry;
 }
 $leMoney = static fn ($value) => $value === null ? '—' : 'Rp ' . number_format((float) $value, 0, ',', '.');
 $leBalance = isset($leBudget['PENDAPATAN']['realisasi'], $leBudget['BELANJA']['realisasi']) ? (float) $leBudget['PENDAPATAN']['realisasi'] - (float) $leBudget['BELANJA']['realisasi'] : null;
@endphp
<section class="le-budget-wrap le-wrap" id="transparansi-footer" aria-label="Transparansi anggaran">
 <div class="le-budget">
  <div class="le-budget-intro"><span>TRANSPARANSI</span><h2>APBDes</h2><strong>{{ $tahun ?? '' }}</strong><i class="fa fa-money" aria-hidden="true"></i>@if (empty($leBudgetPage))<a href="{{ site_url() . '?lentera_page=apbdes' }}">Lihat Detail <i class="fa fa-arrow-right" aria-hidden="true"></i></a>@endif</div>
  <div class="le-budget-main"><div class="le-budget-columns">
  @foreach (['PENDAPATAN','BELANJA','PEMBIAYAAN'] as $leType)
   @php
    $leRow = $leBudget[$leType] ?? [];
    $lePlan = isset($leRow['anggaran']) ? (float) $leRow['anggaran'] : null;
    $leActual = isset($leRow['realisasi']) ? (float) $leRow['realisasi'] : null;
    $lePercent = $lePlan !== null && $leActual !== null ? ($lePlan > 0 ? round($leActual / $lePlan * 100, 1) : 0) : null;
    $leArc = max(0, min(100, $lePercent ?? 0));
   @endphp
   <article class="le-budget-column le-budget-tone-{{ $loop->index }}"><h3>{{ $leType }}</h3><div class="le-budget-content"><dl><dt>Anggaran</dt><dd>{{ $leMoney($lePlan) }}</dd><dt>Realisasi</dt><dd>{{ $leMoney($leActual) }}</dd>
   @if ($leType === 'PENDAPATAN')<dt>Sisa setelah belanja</dt><dd class="le-budget-positive">{{ $leMoney($leBalance) }}</dd>@endif
   </dl><div class="le-budget-donut" style="--le-progress:{{ $leArc }}%" aria-label="Realisasi {{ strtolower($leType) }} {{ $lePercent !== null ? $lePercent . ' persen' : 'belum tersedia' }}"><span>{{ $lePercent !== null ? number_format($lePercent, $lePercent == floor($lePercent) ? 0 : 1, ',', '.') . '%' : '—' }}</span></div></div></article>
  @endforeach
  </div></div>
 </div>
</section>
