<article class="le-article">
 <a class="le-article-image" href="{{ $post->url_slug }}">
  @if (!empty($post['gambar']))
   <img src="{{ AmbilFotoArtikel($post['gambar'], 'sedang') }}" alt="{{ $post['judul'] }}" loading="lazy" decoding="async">
  @else
   <div class="le-image-fallback"><i class="fa fa-newspaper-o" aria-hidden="true"></i><span>Kabar Desa</span></div>
  @endif
 </a>
 <div class="le-article-body"><span class="le-article-date"><i class="fa fa-calendar-o" aria-hidden="true"></i> {{ tgl_indo($post['tgl_upload']) }}</span>
 <h3><a href="{{ $post->url_slug }}">{{ $post['judul'] }}</a></h3>
 <p>{{ \Illuminate\Support\Str::limit(trim(strip_tags($post['isi'] ?? '')), 90) }}</p>
 <div class="le-article-meta"><span><i class="fa fa-user" aria-hidden="true"></i> {{ $post['owner'] ?? 'Admin' }}</span><a href="{{ $post->url_slug }}" aria-label="Baca {{ $post['judul'] }}">Baca <i class="fa fa-arrow-right" aria-hidden="true"></i></a></div></div>
</article>
