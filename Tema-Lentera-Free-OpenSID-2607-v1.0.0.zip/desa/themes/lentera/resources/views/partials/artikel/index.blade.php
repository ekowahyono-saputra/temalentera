@extends('theme::layouts.right-sidebar')
@section('content')
 @php
  $title = !empty($judul_kategori) ? $judul_kategori : (!empty($cari) ? 'Hasil pencarian' : 'Artikel Terkini');
  if (is_array($title)) $title = implode(' / ', $title);
 @endphp
 <div class="le-section-title"><div><span class="le-kicker">DARI DESA UNTUK WARGA</span><h2>{{ $title }}</h2></div><a href="{{ site_url('arsip') }}">Arsip <i class="fa fa-arrow-right" aria-hidden="true"></i></a></div>
 @if (!empty($headline))
 <div class="le-headline">@include('theme::partials.artikel.list', ['post' => $headline])</div>
 @endif
 @if (isset($artikel) && $artikel->count() > 0)
 <div class="le-article-grid">@foreach ($artikel as $post) @include('theme::partials.artikel.list', ['post' => $post]) @endforeach</div>
 @include('theme::commons.page')
 @else
 <div class="le-empty"><i class="fa fa-newspaper-o" aria-hidden="true"></i><h3>Belum ada artikel</h3><p>{{ !empty($cari) ? 'Coba gunakan kata pencarian lainnya.' : 'Kabar terbaru desa akan ditampilkan di sini.' }}</p></div>
 @endif
@endsection
