<nav class="navbar navbar-default le-nav" aria-label="Navigasi utama">
 <div class="navbar-header">
  <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#le-navigation" aria-controls="le-navigation" aria-expanded="false"><span class="sr-only">Buka menu</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
  <span class="le-mobile-label">Jelajahi desa</span>
 </div>
 <div class="collapse navbar-collapse" id="le-navigation">
  <ul class="nav navbar-nav custom_nav"><li><a href="{{ site_url() }}"><i class="fa fa-home" aria-hidden="true"></i> Beranda</a></li>@include('theme::lentera.menu-items', ['leMenuItems' => menu_tema()])</ul>
 </div>
</nav>
