@extends('theme::template')
@section('layout')
<div class="le-news-layout">
 <div class="le-news-main">@yield('content')</div>
 <aside class="le-news-sidebar" aria-label="Informasi artikel">
  @include('theme::lentera.article-sidebar')
 </aside>
</div>
@endsection
