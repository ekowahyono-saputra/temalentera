@extends('theme::template')
@section('layout')
<section class="le-full-content"><div class="content_bottom"><div class="content_left">
 @yield('content')
</div></div></section>
@endsection
