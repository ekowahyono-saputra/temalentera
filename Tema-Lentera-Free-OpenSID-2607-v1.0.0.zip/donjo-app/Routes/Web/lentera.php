<?php
defined('BASEPATH') || exit('No direct script access allowed');
Route::get('lentera-notifikasi/{jenis}/{id}', 'Lentera_notifikasi@preview');
Route::post('lentera-notifikasi/{jenis}/{id}', 'Lentera_notifikasi@send');
