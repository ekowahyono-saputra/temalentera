<?php
use App\Models\LogSurat;
use App\Models\PermohonanSurat;
use App\Models\Penduduk;
use App\Services\LenteraWhatsApp;
defined('BASEPATH') || exit('No direct script access allowed');
class Lentera_notifikasi extends Admin_Controller
{
    public $modul_ini='layanan-surat';
    public $sub_modul_ini='arsip-layanan';
    public function __construct()
    {
        // Set the correct native module before the parent access checks.
        $uri=load_class('URI', 'core');
        $kind=trim((string)$uri->segment(2));
        if ($kind==='permohonan') $this->sub_modul_ini='permohonan-surat';
        parent::__construct();
        isCan('b'); isCan('u');
    }
    private function record($jenis,$id): array
    {
        if (!in_array($jenis,['arsip','permohonan'],true) || !ctype_digit((string)$id)) { show_404(); exit; }
        if (!LenteraWhatsApp::enabled()) { show_error('Gateway notifikasi surat dinonaktifkan.',403); exit; }
        if ($jenis==='permohonan') {
            $row=PermohonanSurat::where('config_id',identitas('id'))->findOrFail((int)$id);
            $name=$row->penduduk->nama ?? 'Pemohon';
            $phone=LenteraWhatsApp::number($row->no_hp_aktif);
            $title=$row->surat->nama ?? 'Layanan surat';
            $status=PermohonanSurat::STATUS_PERMOHONAN[$row->status] ?? 'Perlu dikonfirmasi';
            $message="Informasi permohonan surat #{$row->id}: {$title}. Status: {$status}. Silakan hubungi petugas desa untuk informasi lebih lanjut.";
        } else {
            $pamong=$this->session->isAdmin->pamong ?? null;
            $roles=['jabatan_id'=>$pamong->jabatan_id ?? null,'jabatan_kades_id'=>kades()->id,'jabatan_sekdes_id'=>sekdes()->id];
            $row=LogSurat::where(function($q) use ($pamong,$roles) { $q->arsip($pamong,$roles); })
                ->where('config_id',identitas('id'))->whereNull('deleted_at')->findOrFail((int)$id);
            $pemohon=json_decode((string)$row->pemohon,true);
            // A separate applicant must never silently fall back to the reported person.
            $personId=$row->pemohon ? ($pemohon['id_pend'] ?? null) : $row->id_pend;
            $person=$personId ? Penduduk::where('config_id',identitas('id'))->find($personId) : null;
            $name=$person->nama ?? ($pemohon['nama'] ?? $pemohon['nama_non_warga'] ?? 'Pemohon belum teridentifikasi');
            $phone=$person ? LenteraWhatsApp::number($person->telepon) : '';
            $title=$row->formatSuratArsip->nama ?? 'Layanan surat';
            $status='Tercatat di arsip layanan';
            $message="Informasi layanan desa: surat {$title} nomor {$row->no_surat} telah tercatat pada arsip layanan. Silakan hubungi petugas untuk konfirmasi penyelesaian dan pengambilan surat.";
        }
        return compact('row','name','phone','title','status','message','jenis');
    }
    public function preview($jenis,$id)
    {
        $data=$this->record($jenis,$id);
        $token=bin2hex(random_bytes(24));
        // Store exact record + recipient snapshot; deny sends after a changed recipient/record.
        $this->session->set_userdata('le_notice_'.$token,['kind'=>$jenis,'id'=>(int)$id,'phone'=>$data['phone'],'name'=>$data['name'],'state'=>$data['status'],'title'=>$data['title'],'at'=>time()]);
        $data['token']=$token;$data['result']=$this->session->flashdata('le_notice_result');
        $data['form_action']=site_url('lentera-notifikasi/'.$jenis.'/'.(int)$id);
        $data['back']=site_url($jenis==='arsip' ? 'keluar' : 'permohonan_surat_admin');
        $this->output->set_header('Cache-Control: private, no-store');
        return view('admin.lentera.notifikasi',$data);
    }
    public function send($jenis,$id)
    {
        $data=$this->record($jenis,$id);
        if (!$this->config->item('csrf_protection')) { show_error('Aktifkan proteksi CSRF OpenSID.',503); return; }
        $token=(string)$this->input->post('notice_token');
        if (!preg_match('/^[a-f0-9]{48}$/D',$token)) { show_error('Formulir tidak sah.',422);return; }
        $snapshot=$this->session->userdata('le_notice_'.$token);
        $this->session->unset_userdata('le_notice_'.$token);
        if (!$snapshot || $snapshot['kind']!==$jenis || $snapshot['id']!==(int)$id || time()-$snapshot['at']>1800 || $snapshot['phone']!==$data['phone'] || $snapshot['name']!==$data['name'] || $snapshot['state']!==$data['status'] || $snapshot['title']!==$data['title'] || $this->input->post('verified')!=='1') {
            show_error('Formulir kedaluwarsa atau penerima berubah. Buka kembali tombol WhatsApp.',422);return;
        }
        // Staff may supply a verified number when the source record lacks one.
        $number=LenteraWhatsApp::number($this->input->post('number'));
        $message=trim(strip_tags((string)$this->input->post('message')));
        $result=LenteraWhatsApp::send($number,$message,'manual-'.$jenis.'-'.(int)$id);
        $this->session->set_flashdata('le_notice_result',$result);
        redirect('lentera-notifikasi/'.$jenis.'/'.(int)$id);
    }
}
