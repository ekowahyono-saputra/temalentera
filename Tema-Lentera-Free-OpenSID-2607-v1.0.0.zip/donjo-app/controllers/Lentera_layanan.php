<?php
// Retired public message endpoint, retained to safely replace installations <=1.22.
defined('BASEPATH') || exit('No direct script access allowed');
class Lentera_layanan extends Web_Controller
{
 public function index() { show_404(); }
}
