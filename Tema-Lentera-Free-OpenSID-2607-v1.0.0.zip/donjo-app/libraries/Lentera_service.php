<?php
/** Lentera 1.20 — server-only BMKG cache and Mpedia transport. GPL-3.0-or-later. */
defined('BASEPATH') || exit('No direct script access allowed');
class Lentera_service
{
    public static function request($url, $post = null)
    {
        if (!function_exists('curl_init')) return null;
        $ch = curl_init($url); $body = '';
        curl_setopt_array($ch, [CURLOPT_FOLLOWLOCATION=>false, CURLOPT_CONNECTTIMEOUT=>2,
            CURLOPT_TIMEOUT=>$post === null ? 3 : 12, CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_SSL_VERIFYHOST=>2, CURLOPT_USERAGENT=>'Lentera/1.20',
            CURLOPT_WRITEFUNCTION=>static function ($ch, $chunk) use (&$body) {
                if (strlen($body) + strlen($chunk) > 1048576) return 0;
                $body .= $chunk; return strlen($chunk);
            }]);
        if ($post !== null) curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>http_build_query($post), CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded']]);
        $ok = curl_exec($ch); $status = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($ok === false || $status < 200 || $status >= 300) return null;
        $data = json_decode($body, true); return is_array($data) ? $data : null;
    }
    public static function cacheDir()
    {
        // Outside public theme assets; only hashes and counters, never API credentials.
        $dir = APPPATH . 'cache/lentera';
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) return null;
        return $dir;
    }
    public static function bmkg($type, $code = '')
    {
        if ($type === 'weather' && !preg_match('/^\d{2}\.\d{2}\.\d{2}\.\d{4}$/D', $code)) return null;
        $url = $type === 'weather' ? 'https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=' . rawurlencode($code) : 'https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json';
        $dir = self::cacheDir(); if (!$dir) return null;
        $file = $dir . '/bmkg-' . hash('sha256', $url);
        $h = @fopen($file, 'c+'); if (!$h) return null;
        if (!flock($h, LOCK_EX | LOCK_NB)) { fclose($h); return null; }
        try {
            $cached = json_decode(stream_get_contents($h), true) ?: [];
            $ttl = $type === 'weather' ? 1800 : 300;
            if (time() >= ($cached['retry_at'] ?? 0)) {
                $data = self::request($url);
                $valid = $type === 'weather' ? !empty($data['data'][0]['cuaca']) : !empty($data['Infogempa']['gempa']['DateTime']);
                if ($valid) $cached = ['data'=>$data, 'at'=>time()];
                $cached['retry_at'] = time() + ($valid ? $ttl : 120);
                rewind($h); ftruncate($h, 0); fwrite($h, json_encode($cached)); fflush($h);
            }
            if (empty($cached['data'])) return null;
            $cached['stale'] = time() - ($cached['at'] ?? 0) > $ttl;
            return $cached;
        } finally { flock($h, LOCK_UN); fclose($h); }
    }
    public static function reserve($village, $ip)
    {
        $dir = self::cacheDir(); if (!$dir) return false;
        // One atomic village-wide ledger prevents concurrent quota bypass.
        $h = @fopen($dir . '/wa-' . hash('sha256', (string)$village), 'c+');
        if (!$h) return false;
        if (!flock($h, LOCK_EX)) { fclose($h); return false; }
        try {
            $rows = json_decode(stream_get_contents($h), true) ?: [];
            $rows = array_values(array_filter($rows, static function ($r) { return $r['at'] > time()-3600; }));
            $key = hash('sha256', $ip); $mine = array_values(array_filter($rows, static function ($r) use ($key) { return $r['ip'] === $key; }));
            if (count($rows) >= 30 || count($mine) >= 3 || ($mine && end($mine)['at'] > time()-60)) return false;
            $rows[] = ['ip'=>$key,'at'=>time()]; rewind($h); ftruncate($h,0); fwrite($h,json_encode($rows)); fflush($h); return true;
        } finally { flock($h,LOCK_UN); fclose($h); }
    }
}
