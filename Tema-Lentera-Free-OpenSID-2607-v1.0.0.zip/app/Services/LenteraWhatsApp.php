<?php
namespace App\Services;

/** Mpedia integration for OpenSID 2607.0.1. Never exposes credentials to public views. */
class LenteraWhatsApp
{
    private static ?array $cachedOptions = null;
    public static function options(): array
    {
        if (self::$cachedOptions !== null) return self::$cachedOptions;
        try {
            get_instance()->load->helper('theme');
            $theme = theme_active();
            if (!$theme || basename(rtrim((string)$theme->path, '/')) !== 'lentera') return [];
            return self::$cachedOptions = (array)($theme->opsi ?? []);
        } catch (\Throwable $e) { return []; }
    }
    public static function enabled(): bool
    {
        return (string)(self::options()['lentera_wa_active'] ?? '0') === '1';
    }
    public static function number($value): string
    {
        $n = preg_replace('/[^0-9]/', '', (string)$value);
        if (substr($n,0,1)==='0') $n='62'.substr($n,1);
        elseif (substr($n,0,1)==='8') $n='62'.$n;
        return preg_match('/^62[0-9]{8,13}$/D',$n) ? $n : '';
    }
    public static function send(string $number, string $message, string $context, bool $once = false): array
    {
        $o=self::options();
        if (!self::enabled()) return ['ok'=>false,'message'=>'Gateway notifikasi surat sedang nonaktif.'];
        if ((string)($o['lentera_wa_active'] ?? '0') !== '1') return ['ok'=>false,'message'=>'Gateway notifikasi surat sedang nonaktif.'];
        $number=self::number($number); $sender=self::number($o['lentera_wa_sender'] ?? ''); $key=trim((string)($o['lentera_wa_key'] ?? ''));
        if (!$number || !$sender || !$key || !function_exists('curl_init')) return ['ok'=>false,'message'=>'Nomor tujuan, API key, nomor pengirim, atau ekstensi cURL belum siap.'];
        if (strlen($message)<5 || strlen($message)>3000) return ['ok'=>false,'message'=>'Pesan harus berisi 5–3000 byte teks.'];
        require_once APPPATH.'libraries/Lentera_service.php';
        $dir=\Lentera_service::cacheDir();
        if (!$dir) return ['ok'=>false,'message'=>'Folder log notifikasi belum dapat ditulis.'];
        $fingerprint=hash('sha256',identitas('id').'|'.$context.'|'.$number.'|'.($once ? '' : $message));
        $h=@fopen($dir.'/notify-'.$fingerprint, 'c+');
        if (!$h) return ['ok'=>false,'message'=>'Log notifikasi belum dapat ditulis.'];
        if (!flock($h,LOCK_EX | LOCK_NB)) { fclose($h); return ['ok'=>false,'message'=>'Notifikasi yang sama sedang diproses.']; }
        try {
            $prior=json_decode(stream_get_contents($h),true) ?: [];
            if ($prior && ($once || time()-($prior['at'] ?? 0)<900)) return ['ok'=>false,'message'=>'Notifikasi ini sudah pernah dicoba. Periksa penerima/log gateway sebelum mengirim ulang; jeda pengiriman manual 15 menit.'];
            $record=['at'=>time(),'context'=>$context,'recipient'=>'***'.substr($number,-4),'status'=>'pending','admin_id'=>ci_auth()->id ?? null];
            rewind($h);ftruncate($h,0);fwrite($h,json_encode($record));fflush($h);
            $response=\Lentera_service::request('https://wa.beserver.my.id/send-message',['api_key'=>$key,'sender'=>$sender,'number'=>$number,'message'=>$message]);
            $ok=$response && in_array($response['status'] ?? null,[true,1,'true'],true);
            $record['status']=$ok ? 'accepted' : 'unconfirmed';
            rewind($h);ftruncate($h,0);fwrite($h,json_encode($record));fflush($h);
            if (!$ok) log_message('error','Lentera: status notifikasi surat belum terkonfirmasi; periksa log Mpedia.');
            return ['ok'=>(bool)$ok,'message'=>$ok ? 'Gateway menerima notifikasi. Status diterima/dibaca dapat diperiksa di Mpedia.' : 'Pengiriman belum terkonfirmasi. Jangan langsung mengulang; periksa log Mpedia.'];
        } finally { flock($h,LOCK_UN);fclose($h); }
    }
    public static function submitted($application): void
    {
        $o=self::options();
        if ((string)($o['lentera_wa_active'] ?? '0')!=='1' || (string)($o['lentera_wa_auto_request'] ?? '0')!=='1') return;
        if ((int)$application->config_id !== (int)identitas('id')) return;
        $village=(string)identitas('nama_desa');
        $contact=self::number(identitas('hp_kontak'));
        if ($contact) self::send($contact,"Pemberitahuan layanan surat {$village}: ada permohonan baru #{$application->id}. Silakan periksa menu Permohonan Surat pada admin OpenSID.",'new-office-'.(int)$application->id,true);
        // The application explicitly records the applicant's active number.
        $citizen=self::number($application->no_hp_aktif);
        if ($citizen) self::send($citizen,"Permohonan surat Anda #{$application->id} telah diterima oleh layanan desa {$village} dan akan diperiksa petugas. Pemberitahuan ini bukan persetujuan atau tanda surat sudah selesai.",'new-citizen-'.(int)$application->id,true);
    }
}
